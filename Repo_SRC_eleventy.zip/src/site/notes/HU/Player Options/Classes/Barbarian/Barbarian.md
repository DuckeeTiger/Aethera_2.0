---
{"dg-publish":true,"permalink":"/hu/player-options/classes/barbarian/barbarian/","dg-note-properties":{"aliases":null,"id":"barbarian","lang":"hu","translation":"[[EN/Player Options/Classes/Barbarian/Barbarian|Barbarian]]"}}
---

# Barbarian
*A Fierce Warrior of Primal Rage*

A barbárok hatalmas harcosok, akiket a multiverzum ősi erői táplálnak, melyek „Rage” formájában nyilvánulnak meg. Ez a Rage több, mint puszta érzelem – és nem korlátozódik a haragra –, hanem a ragadozó vadászatának kegyetlensége, a vihar dühe és a tenger háborgása megtestesülése.

Egyes barbárok a Rage-ket egy vad szellemként vagy tisztelt ősükként személyesítik meg. Mások a világ fájdalmához és gyötrelmeihez fűződő kapcsolattá, a vad mágia személytelen kusza hálójává, vagy saját legmélyebb énjük kifejeződésévé tekintik. Minden barbár számára a Rage egy olyan erő, amely nemcsak a harci képességeket táplálja, hanem a rejtélyes reflexeket és a fokozott érzékeket is.

A barbárok gyakran védelmezőként és vezetőként szolgálnak közösségeikben. Fejjel előre rohannak a veszélybe, hogy azoknak, akiket védenek, ne kelljen ezt tenniük. A veszélytől való félelem nélküli bátorságuk miatt a barbárok tökéletesen alkalmasak a kalandokra.

| Core Barbarian Traits           |                                                                                     |
| :------------------------------ | :---------------------------------------------------------------------------------- |
| **Primary Ability**             | Strength                                                                            |
| **Hit Dice Die**                | D12 per Barbarian level                                                             |
| **Saving Throws Proficiencies** | Strength and Constitution                                                           |
| **Skill Proficiencies**         | Choose 2: Animal Handling, Athletics, Intimidation, Nature, Perception, or Survival |
| **Weapon Proficiencies**        | Simple and Martial weapons                                                          |
| **Armor Training**              | Light and Medium armor and Shields                                                  |
| **Starting Equipment**          | Choose A or B: (A) Greataxe, 4 Handaxes, Explorer’s Pack and 15 GP; or (B) 75 GP    |
### Becoming a Barbarian

##### As a Level 1 Character
- Gain all the traits in the Core Barbarian Traits table.
- Gain the Barbarian’s level 1 features, which are listed in the Barbarian Features table.

##### As a Multiclass Character
- Gain the following traits from the Core Barbarian Traits table: Hit Point Die, proficiency with Martial weapons, and training with Shields.
- Gain the Barbarian’s level 1 features, which are listed in the Barbarian Features table.

### Barbarian Class Features

As a Barbarian, you gain the following class features when you reach the specified Barbarian levels. These features are listed in the Barbarian Features table.

| Level | Prof.  <br>Bonus | Class Features                          | Rages | Rage  <br>Damage | Weapon  <br>Mastery |
| ----- | ---------------- | --------------------------------------- | ----- | ---------------- | ------------------- |
| 1     | +2               | Rage, Unarmored Defense, Weapon Mastery | 2     | +2               | 2                   |
| 2     | +2               | Danger Sense, Reckless Attack           | 2     | +2               | 2                   |
| 3     | +2               | Barbarian Subclass, Primal Knowledge    | 3     | +2               | 2                   |
| 4     | +2               | Ability Score Improvement               | 3     | +2               | 3                   |
| 5     | +3               | Extra Attack, Fast Movement             | 3     | +2               | 3                   |
| 6     | +3               | Subclass Feature                        | 4     | +2               | 3                   |
| 7     | +3               | Feral Instinct, Instinctive Pounce      | 4     | +2               | 3                   |
| 8     | +3               | Ability Score Improvement               | 4     | +2               | 3                   |
| 9     | +4               | Brutal Critical                         | 4     | +3               | 3                   |
| 10    | +4               | Subclass Feature                        | 4     | +3               | 4                   |
| 11    | +4               | Relentless Rage                         | 4     | +3               | 4                   |
| 12    | +4               | Ability Score Improvement               | 5     | +3               | 4                   |
| 13    | +5               | Improved Brutal Strike                  | 5     | +3               | 4                   |
| 14    | +5               | Subclass Feature                        | 5     | +3               | 4                   |
| 15    | +5               | Persistent Rage                         | 5     | +3               | 4                   |
| 17    | +6               | Improved Brutal Strike                  | 6     | +4               | 4                   |
| 16    | +5               | Ability Score Improvement               | 5     | +4               | 4                   |
| 18    | +6               | Indomitable Might                       | 6     | +4               | 4                   |
| 19    | +6               | Epic Boon                               | 6     | +4               | 4                   |
| 20    | +6               | Primal Champion                         | 6     | +4               | 4                   |

---
##### Level 1: Rage
You can imbue yourself with a primal power called Rage, a force that grants you extraordinary might and resilience. You can enter it as a Bonus Action if you aren’t wearing Heavy Armor.

You can enter your Rage the number of times shown for your Barbarian level in the Rages column of the Barbarian Features table. You regain one expended use when you finish a Short Rest, and you regain all expended uses when you finish a Long Rest.

While active, your Rage follows the rules below.
- **Damage Resistance**. You have Resistance to Bludgeoning, Piercing, and Slashing damage.
- **Rage Damage**. When you make an attack using Strength—with either a weapon or an Unarmed Strike—and deal damage to the target, you gain a bonus to the damage that increases as you gain levels as a Barbarian, as shown in the Rage Damage column of the Barbarian Features table.
- **Strength Advantage**. You have Advantage on Strength checks and Strength saving throws.
- **No Concentration or Spells**. You can't maintain Concentration, and you can't cast spells.

**Duration**. The Rage lasts until the end of your next turn, and it ends early if you don Heavy Armor or have the Incapacitated condition. If your Rage is still active on your next turn, you can extend the Rage for another round by doing one or more of the following:
- Make an attack roll against an enemy.
- Force an enemy to make a saving throw.
- Take a Bonus Action to extend your Rage.

Each time the Rage is extended, it lasts until the end of your next turn. You can maintain a Rage for up to 10 minutes.

---
##### Level 1: Unarmored Defense
While you aren’t wearing any armor, your base Armor Class equals 10 plus your Dexterity and Constitution modifiers. You can use a Shield and still gain this benefit.

---
##### Level 1: Weapon Mastery
Your training with weapons allows you to use the mastery properties of two kinds of Simple or Martial Melee weapons of your choice, such as Greataxes and Handaxes. Whenever you finish a Long Rest, you can practice weapon drills and change one of those weapon choices.

When you reach certain Barbarian levels, you gain the ability to use the mastery properties of more kinds of weapons, as shown in the Weapon Mastery column of the Barbarian Features table.

---
##### Level 2: Danger Sense
You gain an uncanny sense of when things aren’t as they should be, giving you an edge when you dodge perils. You have Advantage on Dexterity saving throws unless you have the Incapacitated condition.

---
##### Level 2: Reckless Attack
You can throw aside all concern for defense to attack with increased ferocity. When you make your first attack roll on your turn, you can decide to attack recklessly. Doing so gives you Advantage on attack rolls using Strength until the start of your next turn, but attack rolls against you have Advantage during that time.

---
##### Level 3: Barbarian Subclass
You gain a Barbarian subclass of your choice. A subclass is a specialization that grants you features at certain Barbarian levels. For the rest of your career, you gain each of your subclass’s features that are of your Barbarian level or lower.

---
##### Level 3: Primal Knowledge
You gain proficiency in another skill of your choice from the skill list available to Barbarians at level 1.

In addition, while your Rage is active, you can channel primal power when you attempt certain tasks; whenever you make an ability check using one of the following skills, you can make it as a Strength check even if it normally uses a different ability: Acrobatics, Intimidation, Perception, Stealth, or Survival. When you use this ability, your Strength represents primal power coursing through you, honing your agility, bearing, and senses.

---
##### Level 4: Ability Score Improvement
You gain the Ability Score Improvement feat or another **feat** of your choice for which you qualify. You gain this feature again at Barbarian levels 8, 12, and 16.

---
##### Level 5: Extra Attack
You can attack twice, instead of once, whenever you take the Attack action on your turn.

---
##### Level 5: Fast Movement
Your Speed increases by 10 feet while you aren’t wearing Heavy Armor.

---
##### Level 7: Feral Instinct
Your instincts are so honed that you have Advantage on Initiative rolls.

---
##### Level 7: Instinctive Pounce
As part of the Bonus Action you take to enter your Rage, you can Move up to half your Speed.

---
##### Level 9: Brutal Strike
If you use Reckless Attack, you can forgo any Advantage on one Strength-based attack roll of your choice on your turn. The chosen attack roll mustn’t have Disadvantage. If the chosen attack roll hits, the target takes an extra 1d10 damage of the same type dealt by the weapon or Unarmed Strike, and you can cause one Brutal Strike effect of your choice. You have the following effect options.
- **Forceful Blow**. The target is pushed 15 feet straight away from you. You can then move up to half your Speed straight toward the target without provoking Opportunity Attacks.
- **Hamstring Blow**. The target’s Speed is reduced by 15 feet until the start of your next turn. A target can be affected by only one Hamstring Blow at a time—the most recent one.

---
##### Level 11: Relentless Rage
Your Rage can keep you fighting despite grievous wounds. If you drop to 0 Hit Points while your Rage is active and don’t die outright, you can make a DC 10 Constitution saving throw. If you succeed, your Hit Points instead change to a number equal to twice your Barbarian level.

Each time you use this feature after the first, the DC increases by 5. When you finish a Short or Long Rest, the DC resets to 10.

---
##### Level 13: Improved Brutal Strike
You have honed new ways to attack furiously. The following effects are now among your Brutal Strike options.
- **Staggering Blow**. The target has Disadvantage on the next saving throw it makes, and it can’t make Opportunity Attacks until the start of your next turn.
- **Sundering Blow**. Before the start of your next turn, the next attack roll made by another creature against the target gains a +5 bonus to the roll. An attack roll can gain only one Sundering Blow bonus.

---
##### Level 15: Persistent Rage
When you roll Initiative, you can regain all expended uses of Rage. After you regain uses of Rage in this way, you can’t do so again until you finish a Long Rest.

In addition, your Rage is so fierce that it now lasts for 10 minutes without you needing to do anything to extend it from round to round. The Rage ends early if you have the Unconscious (not just the Incapacitated condition) or don Heavy Armor.

---
##### Level 17: Improved Brutal Strike
The extra damage your Brutal Strike deals increases to 2d10. In addition, you can use two different Brutal Strike effects when you use your Brutal Strike feature.

---
##### Level 18: Indomitable Might
If your total for a Strength check or Strength saving throw is less than your Strength score, you can use that score in place of the total.

---
##### Level 19: Epic Boon
You gain an Epic Boon feat or another **feat** of your choice for which you qualify. Boon of Irresistible Offense is recommended.

---
##### Level 20: Primal Champion
You embody primal power. Your Strength and Constitution scores increase by 4, to a maximum of 25.

---

### Barbarian Subclasses

A Barbarian subclass is a specialization that grants you features at certain levels, as specified in the subclass. The following subclasses will be available:
- [[Path of the Berserker\|Path of the Berserker]]
- [[Path of the Wild Heart\|Path of the Wild Heart]]
- [[Path of the World Tree\|Path of the World Tree]]
- [[Path of the Zealot\|Path of the Zealot]]
